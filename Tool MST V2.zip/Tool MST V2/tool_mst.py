# -*- coding: utf-8 -*-
from PIL import Image, ImageTk, ImageFilter
import PIL.Image
import tkinter as tk
from tkinter import *
from tkinter import ttk
import threading
import os



import tkinter as tk
from tkinter import ttk, filedialog,  messagebox
from gui_internals import GUIInternals
from queue import Queue, Empty
import ctypes
try:
    myappid = 'com.deloitte.mst.1' # arbitrary string
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
except: pass

class App(ttk.Frame):
    def __init__(self, parent):
        ttk.Frame.__init__(self)

        # Make the app responsive
        for index in [0]:
            self.columnconfigure(index=index, weight=1)
            self.rowconfigure(index=index, weight=1)

        # Create value lists
        self.option_menu_list = ["", "OptionMenu", "Option 1", "Option 2"]
        self.combo_list = ["Combobox", "Editable item 1", "Editable item 2"]
        self.readonly_combo_list = ["Readonly combobox", "Item 1", "Item 2"]

        # Create control variables
        self.var_0 = tk.BooleanVar()
        self.var_1 = tk.BooleanVar(value=True)
        self.var_2 = tk.BooleanVar()
        self.var_3 = tk.IntVar(value=2)
        self.var_4 = tk.StringVar(value=self.option_menu_list[1])
        self.var_5 = tk.DoubleVar(value=75.0)

        self.filename = tk.StringVar(value="")
        try:
            f = open(os.path.dirname(os.path.realpath(__file__)) + "/file.cfg" , "r")
            self.filename.set(f.read())
        except:
            pass
        self.status = tk.StringVar(value="READY!")
        self.use_temp = tk.IntVar(value=1)

        # Create widgets :)
        self.setup_widgets()
    
    def browseFiles(self):
        self.filename.set(filedialog.askopenfilename(initialdir = os.path.dirname(os.path.realpath(__file__)),
                                            title = "Select a File",
                                            filetypes = (("File excel",
                                                            "*.xls*"),
                                                        ("all files",
                                                            "*.*"))))
        # self.filenametext.config(text="Filename: " + self.filename.get())
        f = open(os.path.dirname(os.path.realpath(__file__)) + "/file.cfg", "w")
        f.write(self.filename.get())
        f.close()
        print(self.filename.get())


    def setup_widgets(self):
        # Create a Frame for the Checkbuttons
        self.check_frame = ttk.LabelFrame(self, text="Chọn file danh sách MST")
        self.check_frame.grid(
            row=0, column=0, padx=(20, 20), pady=(20, 20), sticky="nsew"
        )

        self.folderselectorbutton = ttk.Button(
            self.check_frame, text="Mở file", command=self.browseFiles
        )
        self.folderselectorbutton.grid(row=0, column=0, padx=5, pady=10, sticky="nsew")

                # # Entry
        # self.entry = ttk.Entry(self.widgets_frame)
        # self.entry.insert(0, "Entry")
        # self.entry.grid(row=0, column=0, padx=5, pady=(0, 10), sticky="ew")

        self.filenametext = ttk.Entry(
            self.check_frame,
            textvariable=self.filename,
            # justify="center",
            # font=("-size", 10, "-weight", "bold"),
        )
        self.filenametext.grid(row=1, column=0, padx=5, pady=(0, 10), sticky="ew")


         # Create a Frame for input widgets
        self.widgets_frame = ttk.Frame(self, padding=(0, 0, 0, 10))
        self.widgets_frame.grid(
            row=1, column=0, padx=10, pady=(10, 10), sticky="nsew", rowspan=3
        )
        self.widgets_frame.columnconfigure(index=0, weight=1)


        def step():
            print('use_temp',self.use_temp.get(), self.use_temp.get() == 1)
            GUIInternals.download(self.filename.get(), self.statustext, os.path.dirname(os.path.realpath(__file__)), self.use_temp.get() == 1)
            messagebox.showinfo(title="Hoàn thành", message="Hoàn thành" )
        
        def func():
            if os.path.exists(self.filename.get()):
                self.statustext.config(text='STARTING...')
                threading.Thread(target= step, daemon=True).start()
            else: messagebox.showwarning(title="Lỗi", message="Chưa chọn file!" )

        # Switch
        self.switch = ttk.Checkbutton(
            self.widgets_frame, text="Không cập nhật lại MST đã tải", style="Switch.TCheckbutton", variable=self.use_temp
        )
        self.switch.grid(row=0, column=0, padx=5, pady=10, sticky="nsew")

        # Accentbutton
        self.accentbutton = ttk.Button(
            self.widgets_frame, text="Bắt đầu tool", style="Accent.TButton", command=func
        )
        self.accentbutton.grid(row=1, column=0, padx=5, pady=10, sticky="nsew")

        self.statustext = ttk.Label(
            self.widgets_frame,
            text=self.status.get(),
            justify="center",
            font=("-size", 10, "-weight", "bold"),
        )

        self.statustext.grid(row=2, column=0, pady=10, columnspan=2)


if __name__ == "__main__":
    deloittelogo = "deloitte.ico"
    root = tk.Tk()
    root.title("Tool MST")
    dir_path = os.path.dirname(os.path.realpath(__file__))
    root.tk.call('source', os.path.join(dir_path, 'azure.tcl'))
    root.tk.call("set_theme", "light")

    try:
        root.iconbitmap(os.path.join(dir_path, deloittelogo) )
    except Exception as a:
        pass   


    app = App(root)
    app.pack(fill="both", expand=True)

    # Set a minsize for the window, and place it in the middle
    root.update()
    root.resizable(False, False)
    # root.minsize(root.winfo_width(), root.winfo_height())
    # x_cordinate = int((root.winfo_screenwidth() / 2) - (root.winfo_width() / 2))
    # y_cordinate = int((root.winfo_screenheight() / 2) - (root.winfo_height() / 2))
    # root.geometry("+{}+{}".format(x_cordinate, y_cordinate-20))

    root.mainloop()

